package school.sptech.exercicio.controller;

import org.apache.coyote.Response;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import school.sptech.exercicio.Carro;

import java.util.ArrayList;


@RestController
@RequestMapping("/carros")
public class CarroController {
    public ArrayList<Carro> carros = new ArrayList<>();
    private int id;

    @GetMapping
    public ResponseEntity<ArrayList<Carro>> exibirLista() {
        if (verificarLista() == true) {
            return ResponseEntity.status(200).body(carros);
        }
        return ResponseEntity.status(204).build();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Carro> buscaId(@PathVariable int id) {
        if (verificarLista()) {
            if (verificarId(id)) {
                for (Carro c : carros) {
                    if (c.getId() == id) {
                        return ResponseEntity.status(200).body(c);
                    }
                }
            return ResponseEntity.status(404).build();
            }
        }
        return ResponseEntity.status(404).build();
    }

    @GetMapping("/valor-medio")
    public ResponseEntity<Double> valorMedio(@RequestParam String marca) {
        Double precoMedio = 0.;
        int carroMarca = 0;
        if (marcaExiste(marca)){
            for (Carro c : carros) {
                if (c.getMarca().equalsIgnoreCase(marca)) {
                    precoMedio += c.getPreco();
                    carroMarca++;
                }
            }
            precoMedio = precoMedio / carroMarca;
            return ResponseEntity.status(200).body(precoMedio);
        }
        return ResponseEntity.status(204).build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<Carro> alterarCarro(@PathVariable int id, @RequestBody Carro alterarCarro) {
        int i = 0;
        for (Carro c : carros) {
            if (c.getId() == id) {
                if (placaValida(alterarCarro.getPlaca())) {
                    return ResponseEntity.status(400).build();
                }
                if (placaDuplicada(alterarCarro.getPlaca())) {
                    if (placaDuplicada(alterarCarro.getPlaca(), id)) {
                        carros.set(i, alterarCarro);
                        return ResponseEntity.status(200).body(carros.get(i));
                    }
                    return ResponseEntity.status(409).build();
                }
                carros.set(i, alterarCarro);
                return ResponseEntity.status(200).body(carros.get(i));
            }
            i++;
        }
        return ResponseEntity.status(404).build();
    }

    @PostMapping
    public ResponseEntity<Carro> cadastrarCarro(@RequestBody Carro cadastrarCarro) {
        if (verificarId(id))
        {
            if (!placaDuplicada(cadastrarCarro.getPlaca(), cadastrarCarro.getId())) {
                return ResponseEntity.status(201).build();
            }
        }
        carros.add(cadastrarCarro);
        return ResponseEntity.status(200).body(cadastrarCarro);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Carro> ExcluirCarro(@PathVariable int id) {
        if (verificarId(id)) {
            for (int i = 0; i < carros.size(); i++) {
                if (carros.get(i).getId() == id) {
                    carros.remove(i);
                    return ResponseEntity.status(204).build();
                }
            }
        }
        return ResponseEntity.status(404).build();
    }

    @PatchMapping("/{id}/emplacamento/{placa}")
    public ResponseEntity<Carro> alterarPlaca(@PathVariable String placa, @PathVariable int id) {
        for (Carro c : carros) {
            if (c.getId() == id) {
                if (placaValida(placa)) {
                    return ResponseEntity.status(400).build();
                }
                if (placaDuplicada(placa)) {
                    return ResponseEntity.status(409).build();
                }
                c.setPlaca(placa);
                return ResponseEntity.status(200).body(c);
            }
        }
        return ResponseEntity.status(404).build();
    }

    public boolean verificarLista() {
        if (carros.isEmpty()) {
            return false;
        }
        return true;
    }

    public boolean verificarId(int id) {
        for (int i = 0; i < carros.size(); i++) {
            if (carros.get(i).getId() == id) {
                return true;
            }
        }
        return false;
    }

    public boolean verificarPlaca(String placa) {
        for (int i = 0; i < carros.size(); i++) {
            if (carros.get(i).getPlaca() == placa) {
                return false;
            }
        }
        return true;
    }

    public boolean placaValida(String placa) {
        if (placa.matches("^[A-Z]{3}[0-9][A-Z][0-9]{2}$")) {
            return false;
        }
        return true;
    }

    public boolean placaDuplicada(String placa) {
        for (int i = 0; i < carros.size(); i++) {
            if (carros.get(i).getPlaca().equals(placa)) {
                return true;
            }
        }
        return false;
    }

    public boolean placaDuplicada(String placa, int id) {
        for (int i = 0; i < carros.size(); i++) {
            if (carros.get(i).getPlaca().equals(placa) && carros.get(i).getId() == id) {
                return true;
            }
        }
        return false;
    }

    public boolean marcaExiste(String marca){
        for (Carro c: carros){
            if (c.getMarca().equalsIgnoreCase(marca)){
                return true;
            }
        }
        return false;
    }
}
