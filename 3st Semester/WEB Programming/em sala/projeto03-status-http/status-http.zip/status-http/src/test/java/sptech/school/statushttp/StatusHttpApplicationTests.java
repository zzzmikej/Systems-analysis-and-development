package sptech.school.statushttp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StatusHttpApplicationTests {

	@Test
	void contextLoads() {
	}

}
