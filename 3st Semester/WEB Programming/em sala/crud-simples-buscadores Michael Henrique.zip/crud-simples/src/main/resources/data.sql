INSERT INTO Livro (titulo, descricao, data_publicacao) VALUES
                                                           ('Harry Potter e a Pedra Filosofal',
                                                            'Primeiro livro da série Harry Potter, onde o jovem Harry descobre ser um bruxo e vai para Hogwarts.',
                                                            '1997-06-26'),

                                                           ('Harry Potter e a Câmara Secreta',
                                                            'Segundo livro da série Harry Potter, onde Harry enfrenta novos desafios em Hogwarts, incluindo a abertura da Câmara Secreta.',
                                                            '1998-07-02'),

                                                           ('A Game of Thrones',
                                                            'Primeiro livro da série As Crônicas de Gelo e Fogo, onde as casas nobres dos Sete Reinos lutam pelo controle do Trono de Ferro.',
                                                            '1996-08-06'),

                                                           ('A Clash of Kings',
                                                            'Segundo livro da série As Crônicas de Gelo e Fogo, onde a guerra pelo Trono de Ferro se intensifica.',
                                                            '1998-11-16'),

                                                           ('O Senhor dos Anéis: A Sociedade do Anel',
                                                            'Primeiro livro da trilogia O Senhor dos Anéis, onde Frodo Bolseiro inicia sua jornada para destruir o Um Anel.',
                                                            '1954-07-29'),

                                                           ('Cem Anos de Solidão',
                                                            'Obra-prima de Gabriel García Márquez que narra a história da família Buendía na fictícia cidade de Macondo.',
                                                            '1967-05-30'),

                                                           ('Kafka à Beira-Mar',
                                                            'Um dos romances mais conhecidos de Haruki Murakami, que segue a história de um jovem fugitivo e um velho caçador de gatos.',
                                                            '2002-09-12');
