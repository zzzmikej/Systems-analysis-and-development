package sptechschool.crudsimples.controller;

import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import sptechschool.crudsimples.entity.Livro;
import sptechschool.crudsimples.repository.LivroRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;


@RestController
@RequestMapping("/livros")
public class LivroController {

    private LivroRepository LivroRepository;


    @GetMapping
    public ResponseEntity<List<Livro>> listar() {
        List<Livro> livros = LivroRepository.findAll();

        if (livros.isEmpty()) {
            return ResponseEntity.status(204).build();
        }
        return ResponseEntity.status(200).body(livros);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Livro> buscarPorId(@PathVariable int id) {
        Optional<Livro> livroOpt = LivroRepository.findById(id);

        if (livroOpt.isPresent()) {
            return ResponseEntity.status(200).body(livroOpt.get());
        }
        return ResponseEntity.status(404).build();
    }

    @GetMapping("/titulo")
    public ResponseEntity<List<Livro>> buscaPorTitulo(@RequestParam String titulo) {
        List<Livro> livros = LivroRepository.findByTituloContainsIgnoreCase(titulo);

        if (livros.isEmpty()) {
            return ResponseEntity.status(204).build();
        }
        return ResponseEntity.status(200).body(livros);
    }

    @GetMapping("/data")
    public ResponseEntity<List<Livro>> buscaPorDataPublicacao(@RequestParam("dataPublicacao") LocalDate dataPublicacao) {
        List<Livro> livros = LivroRepository.findByDataPublicacaoAfter(dataPublicacao);

        if (livros.isEmpty()) {
            return ResponseEntity.status(204).build();
        }

        return ResponseEntity.status(200).body(livros);
    }
    @GetMapping("/data/titulo")
    public ResponseEntity<List<Livro>> buscaPorDataPublicacaoEParcialTitulo(
            @RequestParam("dataInicial") LocalDate dataInicial,
            @RequestParam("dataFinal") LocalDate dataFinal,
            @RequestParam("titulo") String titulo
    ) {
        List<Livro> livros = LivroRepository.findByDataPublicacaoBetweenAndTituloContainsIgnoreCase(dataInicial, dataFinal, titulo);

        if (livros.isEmpty()) {
            return ResponseEntity.status(204).build();
        }

        return ResponseEntity.status(200).body(livros);
    }

    @GetMapping("/livros/soma")
    public ResponseEntity<Double> somaDosPrecos() {
        List<Livro> livros = LivroRepository.findAll();

        Double somaDosPrecos = LivroRepository.sumPreco();

        if (livros.isEmpty()) {
            return ResponseEntity.status(204).build();
        }

        return ResponseEntity.status(200).body(somaDosPrecos);
    }

    @PostMapping
    public ResponseEntity<Livro> criar(@RequestBody @Valid Livro novoLivro) {
        novoLivro.setId(null);
        Livro filmeSalvo = LivroRepository.save(novoLivro);
        return ResponseEntity.status(201).body(filmeSalvo);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Livro> atualizar(
            @PathVariable int id,
            @RequestBody @Valid Livro livroAtualizado) {

        if (!LivroRepository.existsById(id)) {
            return ResponseEntity.status(404).build();
        }

        livroAtualizado.setId(id);
        Livro livroSalvo = LivroRepository.save(livroAtualizado);
        return ResponseEntity.status(200).body(livroSalvo);
    }
}