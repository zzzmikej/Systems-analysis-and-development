package sptechschool.projetobidirecional;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoBidirecionalApplicationTests {

    @Test
    void contextLoads() {
    }

}
