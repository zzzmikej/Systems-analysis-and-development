INSERT INTO Diretor (name) VALUES ('Quentin Tarantino'),
                                  ('Tim Burton'),
                                  ('Christopher Nolan');
INSERT INTO Filme (title, diretor_id) VALUES ('Tarde da Noite com o Diabo', 1),
                                            ('Sombras da Noite', 2),
                                            ('Interstellar', 3);