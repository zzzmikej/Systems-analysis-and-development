package sptechschool.projetobidirecional.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import sptechschool.projetobidirecional.entity.Diretor;

public interface DiretorRepository extends JpaRepository<Diretor, Integer> {
}
