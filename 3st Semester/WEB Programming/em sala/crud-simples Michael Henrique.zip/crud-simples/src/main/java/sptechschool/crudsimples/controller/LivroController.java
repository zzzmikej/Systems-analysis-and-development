package sptechschool.crudsimples.controller;

import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import sptechschool.crudsimples.entity.Livro;
import sptechschool.crudsimples.repository.LivroRepository;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/livro")
public class LivroController {
    LivroRepository livroRepository;

    @GetMapping
    public ResponseEntity<List<Livro>> getList(){
        List<Livro> listLivros = livroRepository.findAll();

        if (listLivros.isEmpty()){
            return ResponseEntity.status(204).build();
        }

        return ResponseEntity.status(200).body(listLivros);
    }


    @GetMapping("/{id}")
    public ResponseEntity<Livro> getById(@PathVariable Integer id){
        Optional<Livro> opt = livroRepository.findById(id);

        if (opt.isEmpty()){
            return ResponseEntity.status(404).build();
        }

        return ResponseEntity.status(200).body(opt.get());
    }

    @PostMapping
    public ResponseEntity<Livro> post(@RequestBody @Valid Livro entity){
        return ResponseEntity.status(200).body((livroRepository.save(entity)));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Livro> putLivro(@PathVariable Integer id, @RequestBody @Valid Livro entity) {
        if (!livroRepository.existsById(id)){
            return ResponseEntity.notFound().build();
        }

        entity.setId(id);
        Livro livro = livroRepository.save(entity);
        return ResponseEntity.status(200).body(entity);
    }
}
