package school.sptech.cursos.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import school.sptech.cursos.entity.Curso;
import school.sptech.cursos.entity.Inscricao;
import school.sptech.cursos.service.CursoService;
import school.sptech.cursos.service.InscricaoService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/inscricoes")
@RequiredArgsConstructor
public class InscricaoController {

    private final InscricaoService service;
    private final CursoService cursoService;

    @GetMapping
    public ResponseEntity<List<Inscricao>> findAll() {
        List<Inscricao> inscricoes = service.findAll();

        if (inscricoes.isEmpty()) {
            return ResponseEntity.noContent().build();
        }

        return ResponseEntity.ok(inscricoes);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Inscricao> findById(@PathVariable Integer id) {
        Optional<Inscricao> inscricao = service.findById(id);

        if (inscricao.isEmpty()) {
            return ResponseEntity.status(404).build();
        }

        return ResponseEntity.status(200).body(inscricao.get());
    }

    @PostMapping("/cursos/{idCurso}")
    public ResponseEntity<Inscricao> save(
            @PathVariable Integer idCurso,
            @RequestBody @Valid Inscricao inscricao
    ) {
        Optional<Curso> cursoOptional = cursoService.findById(idCurso);

        if (!cursoOptional.isPresent()) {
            return ResponseEntity.notFound().build();
        }

        inscricao.setCurso(cursoOptional.get());

        Inscricao inscricaoSalva = service.save(inscricao);
        return ResponseEntity.status(201).body(inscricaoSalva);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Integer id) {
        if (!service.existsById(id)) {
            return ResponseEntity.notFound().build();
        }

        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
