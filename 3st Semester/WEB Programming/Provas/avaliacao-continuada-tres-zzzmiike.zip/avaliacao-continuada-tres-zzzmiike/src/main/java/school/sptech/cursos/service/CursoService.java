package school.sptech.cursos.service;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import school.sptech.cursos.entity.Curso;
import school.sptech.cursos.repository.CursoRepository;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class CursoService {

    private final CursoRepository repository;

    public List<Curso> findAll() {
        return repository.findAll();
    }

    public Optional<Curso> findById(Integer id) {
        return repository.findById(id);
    }

    @Transactional
    public Curso save(Curso curso) {
        if (curso.getCargaHoraria() <= 0){
            throw new IllegalArgumentException("deve ser um número positivo");
        }
        if (curso.getDescricao().isBlank()){
            throw new IllegalArgumentException("não pode estar vazio ou em branco");
        }
        if (curso.getNome().isBlank()){
            throw new IllegalArgumentException("não pode estar vazio ou em branco");
        }
        return repository.save(curso);
    }
}
