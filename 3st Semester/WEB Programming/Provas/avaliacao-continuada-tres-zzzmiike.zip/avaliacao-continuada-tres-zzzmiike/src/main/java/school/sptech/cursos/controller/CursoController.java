package school.sptech.cursos.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import school.sptech.cursos.entity.Curso;
import school.sptech.cursos.service.CursoService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/cursos")
@RequiredArgsConstructor
public class CursoController {

    private final CursoService service;

    @GetMapping
    public ResponseEntity<List<Curso>> findAll() {
        List<Curso> cursosList = service.findAll();

        if (cursosList.isEmpty()) {
            return ResponseEntity.noContent().build();
        }

        return ResponseEntity.ok(cursosList);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Curso> findById(@PathVariable Integer id) {
        Optional<Curso> cursoOptional = service.findById(id);

        if (cursoOptional.isEmpty()){
            return ResponseEntity.status(404).build();
        }

        return ResponseEntity.status(200).body(cursoOptional.get());
    }

    @PostMapping
    public ResponseEntity<Curso> save(@RequestBody @Valid Curso curso) {
        List<Curso> cursosExistentes = service.findAll();
        for (Curso cursoExistente : cursosExistentes) {
            if (cursoExistente.getNome().equals(curso.getNome())){
                return ResponseEntity.status(409).build();
            }
        }

        if (curso.getDescricao().isBlank()){
            throw new IllegalArgumentException("não pode estar vazio ou em branco");
        }

        if (curso.getNome().isBlank()){
            throw new IllegalArgumentException("não pode estar vazio ou em branco");
        }

        Curso salvo = service.save(curso);
        return ResponseEntity.status(201).body(salvo);
    }
}
