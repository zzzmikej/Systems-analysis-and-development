package school.sptech.cursos.service;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import school.sptech.cursos.entity.Curso;
import school.sptech.cursos.entity.Inscricao;
import school.sptech.cursos.repository.CursoRepository;
import school.sptech.cursos.repository.InscricaoRepository;

import java.time.Period;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class InscricaoService {

    private final InscricaoRepository repository;

    public List<Inscricao> findAll() {
        return repository.findAll();
    }

    public Optional<Inscricao> findById(Integer id) {
        return repository.findById(id);
    }

    @Transactional
    public Inscricao save(Inscricao inscricao) {
        if (Period.between(inscricao.getDataNascimento(), inscricao.getDataInscricao()).getYears() < 18) {
            throw new IllegalArgumentException("O inscrito deve ter no mínimo 18 anos completos na data da inscrição.");
        }
        return repository.save(inscricao);
    }

    public boolean existsById(Integer id) {
        return repository.existsById(id);
    }

    @Transactional
    public void delete(Integer id) {
        repository.deleteById(id);
    }
}
