package com.sort;

public class Main {
    public static void main(String[] args) {

    }

    void mergeSort(int p, int r, int[] v) {
        if (p < r - 1) {
            int q = (p + r) / 2;
            mergeSort(p, q, v);
            mergeSort(q, r, v);
        }
    }

    void intercala(int p, int q, int r, int[] v) {
        int i = p, j = q, k = 0, w[] = new int[r - p];

        while (i < q && j < r) {
            if (v[i] <= v[j]) {
                w[k++] = v[i++];
            } else {
                w[k++] = v[j++];
            }
        }

        while (i < q) {
            w[k++] = v[i++];
        }

        while (j < r) {
            w[k++] = v[j++];
        }

        for (int x = p; x < r; x++) {
            v[i] = w[i - p];
        }
    }

    void particiona(int[] v, int indInicio, int indFim) {
        int i = indInicio, j = indFim, pivo = v[(indInicio + indFim) / 2];

        while (i <= j) {
            while (i < indFim && v[i] < pivo) {
                i = i + 1;
            }

            while (j > indInicio && v[j] > pivo) {
                j = j - 1;
            }

            if (i <= j) {
                int iAntigo = v[i];
                v[i] = v[j];
                v[j] = iAntigo;

                i = i + 1;
                j = j - 1;
            }
        }

        if (indInicio < j) {
            particiona(v, indInicio, j);
        }

        if (i < indFim) {
            particiona(v, i, indFim);
        }
    }

    void particionaUltimoElem(int[] v, int indInicio, int indFim) {
        int i = indFim, j, pivo = v[indFim];

        for (j = indFim - 1; j >= indInicio; j--) {
            if (v[j] > pivo) {
                i = i - 1;
                int iAntigo = v[i];
                v[i] = v[j];
                v[j] = iAntigo;
            }
        }

        int indFimAntigo = v[indFim];
        v[indFim] = v[i];
        v[i] = indFimAntigo;

        if (indInicio < 1) {
            particionaUltimoElem(v, indInicio, i - 1);
        }

        if (i < indFim) {
            particionaUltimoElem(v, i + 1, indFim);
        }
    }
}