package Bebida;

public interface Calculo {
    public Double calcularPreco();
}
