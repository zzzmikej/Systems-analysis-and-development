package org.example;

public class Pilha {

    // 01) Atributos
    private int[] pilha;
    private int topo;

    // 02) Construtor
    public Pilha(int capacidade) {

    }

    // 03) MÃ©todo isEmpty
    public Boolean isEmpty() {
        return null;
    }

    // 04) MÃ©todo isFull
    public Boolean isFull() {
        return null;
    }

    // 05) MÃ©todo push
    public void push(int info) {

    }

    // 06) MÃ©todo pop
    public int pop() {
        return 0;
    }

    // 07) MÃ©todo peek
    public int peek() {
        return 0;
    }

    // 08) MÃ©todo exibe
    public void exibe() {

    }


    //Getters & Setters (manter)
    public int getTopo() {
        return topo;
    }
}