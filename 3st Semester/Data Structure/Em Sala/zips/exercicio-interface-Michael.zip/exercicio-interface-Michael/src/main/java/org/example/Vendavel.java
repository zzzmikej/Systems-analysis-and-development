package org.example;

public interface Vendavel {
    Double getValorVenda();
}
