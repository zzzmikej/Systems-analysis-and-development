package sptech;

import java.util.ArrayList;
import java.util.List;

public class Carrinho {
    private List<Produto> produtos;

    public Carrinho() {
        this.produtos = new ArrayList<>();
    }

    public void adicionarProduto(Produto produto) {
        if (!existeProdutoPorCodigoBarras(produto.getCodigoBarras())) {
            this.produtos.add(produto);
        }
    }

    public void removerProduto(Integer indice) {
        if (existePorIndice(indice)) {
            this.produtos.remove(indice);
        }
    }

    public Produto obterProduto(Integer indice) {
        if (existePorIndice(indice)) {
            return this.produtos.get(indice);
        } else {
            return null;
        }
    }

    public Double calcularTotalEmEstoque() {
        Double total = 0.0;
        for (Produto produto : this.produtos) {
            total += produto.calcularPrecoTotal();
        }
        return total;
    }

    public Double calcularTotalEmEstoquePorCategoria(String categoria) {
        Double total = 0.0;
        for (Produto produto : this.produtos) {
            if (produto.getCategoria().equals(categoria)) {
                total += produto.calcularPrecoTotal();
            }
        }
        return total;
    }

    public Boolean existeProdutoPorCodigoBarras(String codigoBarras) {
        for (Produto produto : this.produtos) {
            if (produto.getCodigoBarras().equals(codigoBarras)) {
                return true;
            }
        }
        return false;
    }

    public Boolean existePorIndice(Integer indice) {
        return indice >= 0 && indice < this.produtos.size();
    }

    public List<Produto> buscarPorCategoria(String categoria) {
        List<Produto> produtosEncontrados = new ArrayList<>();
        for (Produto produto : this.produtos) {
            if (produto.getCategoria().equals(categoria)) {
                produtosEncontrados.add(produto);
            }
        }
        return produtosEncontrados;
    }
}
