package veiculo;

public class Main {

    public static void main(String[] args) {
        Carro carro01 = new Carro("Luiz","Toyota", 48500., 2016, 0.5,true);
        Bicicleta bibicleta01 = new Bicicleta("Jospe","Caloi", 1500., 2016, 32.,58.5);

        carro01.relatorioDeRevisao();
        bibicleta01.relatorioDeRevisao();
    }
}
