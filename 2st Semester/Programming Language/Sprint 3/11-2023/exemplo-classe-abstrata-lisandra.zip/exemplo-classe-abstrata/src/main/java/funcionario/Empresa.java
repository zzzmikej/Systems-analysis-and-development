package funcionario;

import figura.Figura;

import java.util.ArrayList;
import java.util.List;

public class Empresa {

    private List<Funcionario> funcionarios;

    public Empresa() {
        this.funcionarios = new ArrayList<>();
    }

    public void adicionarFunc(Funcionario f){
        funcionarios.add(f);
    }

    public void exibeTodos(){
        for (Funcionario f: funcionarios) {
            System.out.println(f);
        }
    }
    public void exibeTotalSalario(){
        Double soma = 0.;
        for (Funcionario f: funcionarios) {
            soma += f.calcSalario();
        }
        System.out.println(soma);
    }

}
