package veiculo;

public class Carro extends Veiculo {
    private Double nivelDeOleo;
    private Boolean possuiEstepe;

    public Carro(String nomeProprietario, String marca, Double valor, Integer anoFabricacao, Double nivelDeOleo, Boolean possuiEstepe) {
        super(nomeProprietario, marca, valor, anoFabricacao);
        this.nivelDeOleo = nivelDeOleo;
        this.possuiEstepe = possuiEstepe;
    }

    @Override
    public void relatorioDeRevisao() {
        System.out.println("Relatório de Revisão do veiculo.Carro:");
        if (nivelDeOleo < 1.5) {
            System.out.println("- Nível de óleo baixo, compre conosco");
        } else {
            System.out.println("- Nível de óleo bom!");
        }

        if (possuiEstepe) {
            System.out.println("- Estepe ok\n");
        } else {
            System.out.println("- Compre estepe conosco!\n");
        }
    }

    public Double getNivelDeOleo() {
        return nivelDeOleo;
    }

    public void setNivelDeOleo(Double nivelDeOleo) {
        this.nivelDeOleo = nivelDeOleo;
    }

    public Boolean getPossuiEstepe() {
        return possuiEstepe;
    }

    public void setPossuiEstepe(Boolean possuiEstepe) {
        this.possuiEstepe = possuiEstepe;
    }

    @Override
    public String toString() {
        return """
    
                %s
                Nível de óleo:   %.2f
                Possui Estepe:   %b
                """.formatted(super.toString(), nivelDeOleo, possuiEstepe);
    }
}
