package funcionario;

public class Main {
    public static void main(String[] args) {
        Empresa empresa01 = new Empresa();

        Vendedor vendedor01 = new Vendedor("111", "Luiz", 5., 10.);

        Horista horista01 = new Horista("222", "Lis",
                3, 10.);

        empresa01.adicionarFunc(vendedor01);
        empresa01.adicionarFunc(horista01);

        empresa01.exibeTodos();

        empresa01.exibeTotalSalario();
    }
}
