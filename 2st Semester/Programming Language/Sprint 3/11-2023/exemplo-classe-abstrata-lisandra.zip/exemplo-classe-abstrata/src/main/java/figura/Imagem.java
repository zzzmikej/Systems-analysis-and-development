package figura;

import java.util.ArrayList;
import java.util.List;

public class Imagem {

    private List<Figura> figuras;

    public Imagem() {
        this.figuras = new ArrayList<>();
    }

    public void adicionarFigura(Figura f){
        figuras.add(f);
    }

    public void exibeFiguras(){
        for (Figura f: figuras) {
            System.out.println(f);
        }
    }

    public void exibeSomaArea(){
        Double soma = 0.;
        for (Figura f: figuras) {
            soma += f.calcularArea();
        }
        System.out.println(soma);
    }

    public void exibeFiguraAreaMaior20(){
        String areas = "";
        for (Figura f: figuras) {
            if (f.calcularArea() > 20){
                areas = f.toString();
            }
        }
        System.out.println(areas);
    }

    public void exibeQuadrado(){
        for (Figura f: figuras) {
            if (f instanceof Quadrado){
                System.out.println(f);
            }
        }
    }
}
