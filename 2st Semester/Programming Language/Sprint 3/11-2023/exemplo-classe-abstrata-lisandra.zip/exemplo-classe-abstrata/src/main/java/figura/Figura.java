package figura;

public abstract class Figura {

    private String cor;
    private Integer espessura;

    public Figura(String cor, Integer espessura) {
        this.cor = cor;
        this.espessura = espessura;
    }

    public abstract Double calcularArea();

    @Override
    public String toString() {
        return """
                ----Figura
                Cor:            %s
                Espessura:      %d
                """.formatted(cor, espessura);
    }
}
