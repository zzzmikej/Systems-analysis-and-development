package veiculo;

public class Bicicleta extends Veiculo {

    private Double calibragemPneus;
    private Double pesoCiclista;

    public Bicicleta(String nomeProprietario, String marca, Double valor, Integer anoFabricacao, Double calibragemPneus, Double pesoCiclista) {
        super(nomeProprietario, marca, valor, anoFabricacao);
        this.calibragemPneus = calibragemPneus;
        this.pesoCiclista = pesoCiclista;
    }

    @Override
    public void relatorioDeRevisao() {
        System.out.println("Relatório de Revisão da veiculo.Bicicleta:");

        if (pesoCiclista <= 70. && calibragemPneus != 33.) {
            System.out.println("- Ajuste a calibragem conosco!\n");
        } else {
            System.out.println("- Calibragem okay!\n");
        }
    }

    public Double getCalibragemPneus() {
        return calibragemPneus;
    }

    public void setCalibragemPneus(Double calibragemPneus) {
        this.calibragemPneus = calibragemPneus;
    }

    public Double getPesoCiclista() {
        return pesoCiclista;
    }

    public void setPesoCiclista(Double pesoCiclista) {
        this.pesoCiclista = pesoCiclista;
    }

    @Override
    public String toString() {
        return """
                
                %s
                Calibragem dos Pneus:   %.2f
                Peso do Ciclista:       %.2f
                """.formatted(super.toString(), calibragemPneus, pesoCiclista);

    }
}

