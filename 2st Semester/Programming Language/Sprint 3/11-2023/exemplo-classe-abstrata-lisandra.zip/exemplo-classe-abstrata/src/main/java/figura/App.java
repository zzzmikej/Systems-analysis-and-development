package figura;

public class App {
    public static void main(String[] args) {
        Imagem imagem01 = new Imagem();

        Triangulo triangulo01 = new Triangulo("Verde água", 5, 9., 10.);

        Retangulo retangulo01 = new Retangulo("Amarelo", 3, 5., 2.);

        Quadrado quadrado01 = new Quadrado("Cinza",3, 6.);

        Circulo circulo01 = new Circulo("Preto", 4, 8.5);

        Triangulo triangulo02 = new Triangulo("Azul", 5, 2., 10.);

        Retangulo retangulo02 = new Retangulo("Roxo", 1, 5., 9.);

        Quadrado quadrado02 = new Quadrado("Branco",3, 9.);

        Circulo circulo02 = new Circulo("Marrom", 1, 15.5);



        imagem01.adicionarFigura(triangulo01);
        imagem01.adicionarFigura(retangulo01);
        imagem01.adicionarFigura(quadrado01);
        imagem01.adicionarFigura(circulo01);
        imagem01.adicionarFigura(triangulo02);
        imagem01.adicionarFigura(retangulo02);
        imagem01.adicionarFigura(quadrado02);
        imagem01.adicionarFigura(circulo02);

        System.out.println("***********Exibe Figuras: ***********");
        imagem01.exibeFiguras();
        System.out.println("*********************************");
        System.out.println("\n***********Soma de Área: ***********");
        imagem01.exibeSomaArea();
        System.out.println("*********************************");
        System.out.println("\n***********Exibe Figuras com Área maior que 20: ***********");
        imagem01.exibeFiguraAreaMaior20();
        System.out.println("\n***********Exibe Quadrado: ***********");
        imagem01.exibeQuadrado();
        System.out.println("*********************************");
    }
}
