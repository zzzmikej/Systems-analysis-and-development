package MichaelHenrique;

public class Main {
    public static void main(String[] args) {
        Prints.bemVindo();
        CafeTech cafe = new CafeTech();
        cafe.exibirMenu();
    }
}
